package zach.devops
import jenkins.model.*

//定义函数,get all pipeline jobs.
@NonCPS
def getPipelineJobNames() {
    Hudson.instance.getAllItems(org.jenkinsci.plugins.workflow.job.WorkflowJob)*.fullName 
}

node {
    //调用函数 
    println getPipelineJobNames()

    //Get all jobs.
    jenkins.model.Jenkins.instance.getJobNames().findAll{ name -> println name }


    def jobs = jenkins.model.Jenkins.instance.getJobNames()
    def matchjobs = jobs.findAll{ name -> name =~ /(A|D|H)\w*/ }
    println matchjobs

}