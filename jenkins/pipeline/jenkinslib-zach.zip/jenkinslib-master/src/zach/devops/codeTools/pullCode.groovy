package zach.devops.codeTools

def PullCode(srcUrl,branchName,credentialsId,tagName="null") {
    echo srcUrl
    //delete 'origin/'
    if (branchName.startsWith('origin/')){
        branchName=branchName.minus("origin/")
    } 
    
    if(tagName == "null"){
        pathName = "*/${branchName}"
    }else{
        pathName = "refs/tags/${tagName}"
    }
    checkout([$class: 'GitSCM', branches: [[name: "${pathName}"]], 
        doGenerateSubmoduleConfigurations: false, 
        extensions: [], submoduleCfg: [], 
        userRemoteConfigs: [[credentialsId: "${credentialsId}", 
        url: "${srcUrl}"]]])
}

def GetCode(srcUrl,branchName,credentialsId,tagName="null") {
    cleanWs()
    script {
        try{
            // git branch: "${params.BRANCH}", credentialsId: 'gitlab', poll: false,  url: '${params.SRC_CODE}'
            PullCode("${params.SRC_CODE}","${params.BRANCH}",'gitlab')
        } catch(e) {
            retry(2){
                PullCode("${params.SRC_CODE}","${params.BRANCH}",'gitlab')
            }
        }
        finally{
            echo 'git clone finish!'

        }
    }
    sh "ls -lah"
}