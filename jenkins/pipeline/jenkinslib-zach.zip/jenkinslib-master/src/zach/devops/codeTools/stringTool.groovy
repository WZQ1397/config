package zach.devops.codeTools
def isEmpty(str){
    return str == "" || str == null
}

def getYamlMeta(txt){
    def firstIndex = txt.indexOf('---')
    if(firstIndex == -1){
        return ""
    }
    def secondIndex = txt.indexOf('---', firstIndex + 3)
    if(secondIndex == -1){
        return ""
    }
    return txt.substring(firstIndex, secondIndex + 3)
}

def PrintMes(value,color){
    //定义字典
    colors = ['red'   : "\033[31m ${value} \033[0m",
              'blue'  : "\033[34m ${value} \033[0m",
              'green' : "\033[32m ${value} \033[0m",
              'deepgreen' : "\033[36m ${value} \033[0m",
              'yellow'   : "\033[33m ${value} \033[0m",
              'purple'  : "\033[35m ${value} \033[0m" ]
    //调用
    ansiColor('xterm') {
        println(colors[color])
    }
}
