def getServer(ip,port){
    def remote = [:]
    remote.name = "server-${ip}"
    remote.host = ip
    remote.port = port.toInteger()
    remote.username = "zach"
    remote.allowAnyHosts = true
    withCredentials([usernamePassword(credentialsId: 'dd5c7fe2-289b-4cab-af02-9a5e4cc7ead4', passwordVariable: 'password', usernameVariable: 'meizhi2018')]) {
    //withCredentials([sshUserPrivateKey(credentialsId: 'ServiceServer', keyFileVariable: 'identity', passphraseVariable: '', usernameVariable: 'userName')]) {
        remote.user = remote.username
        remote.password = "${password}"
    }
    return remote
}
