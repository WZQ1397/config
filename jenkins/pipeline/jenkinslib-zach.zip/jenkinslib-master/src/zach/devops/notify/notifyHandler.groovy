package zach.devops.notify

def workHook(projectId="",status="",content="",type=""){

}

def notify(status,emailUser){
    post{
        success{
            script{
                println("success")
                workHook()
                toemail.Email("构建成功",userEmail)
            }
        }
        failure{
            script{
                println("failure")
                workHook()
                toemail.Email("构建失败",userEmail)
            }
        }
        aborted{
            script{
                println("aborted")
                workHook()
                toemail.Email("构建取消",userEmail)
            }
        }
        
    }
}