#!/usr/bin/env groovy
package zach.devops.notify

/* dingding.groovy
   ##################################################
   # Created by Zach.wang                           #
   #                                                #
   # A Part of the Project jenkins-library          #
   ##################################################
   post{
    success{
        script{
            
            dingding.notice('b446da5d-6c82-41ba-xxxxxxxxx',"192.168.1.124:9090","$MYENV","$PRONAME","$NAMESPACE","构建成功✅","✅✅✅✅✅✅✅✅✅",["13511111111"])
        }
    }
    failure{
        script{
            dingding.notice('b446da5d-6c82-41ba-xxxxxxxxx',"192.168.1.124:9090","$MYENV","$PRONAME","$NAMESPACE","构建失败❌","❌❌❌❌❌❌❌❌❌",["13511111111"])
        }
    }
   
  }
*/

def getChangeString() {
    def changeString = ""
    def MAX_MSG_LEN = 10
    def changeLogSets = currentBuild.changeSets
    for (int i = 0; i < changeLogSets.size(); i++) {
        def entries = changeLogSets[i].items
        for (int j = 0; j < entries.length; j++) {
            def entry = entries[j]
            truncatedMsg = entry.msg.take(MAX_MSG_LEN)
            commitTime = new Date(entry.timestamp).format("yyyy-MM-dd HH:mm:ss")
            changeString += " - ${truncatedMsg} [${entry.author} ${commitTime}]\n"
        }
    }
    if (!changeString) {
        changeString = " - No new changes"
    }
    return (changeString)
}

def notice(robot,jk_url,MYENV,PRONAME,NAMESPACE,statusMessage,headMessage,person=[""]){
    wrap([$class: 'BuildUser']){
         dingtalk (
          robot: ${robot},
          type: 'MARKDOWN',
          title: "${MYENV}_${PRONAME}构建通知",
          text: [
              "# $headMessage",
              "# 构建详情",
              "- 应用名称: ${PRONAME}",
              "- 分支: ${MYENV}",
              "- 构建结果:${statusMessage}",
              "- 构建人: **${env.BUILD_USER}**",
              "- 持续时间: ${currentBuild.durationString}",
              "- 构建日志: [日志](${env.BUILD_URL}console)",
              "# Jenkins链接",
              "[应用Jenkins地址](http://${jk_url}/job/${NAMESPACE}-${MYENV}_${PRONAME}/)"
    
          ],
          at: ${person}
         
        )
    }       
}