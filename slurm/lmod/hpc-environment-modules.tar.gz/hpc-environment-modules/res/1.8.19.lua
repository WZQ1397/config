whatis([===[HDF5 is a data model, library, and file format for storing and managing data. It supports an unlimited variety of datatypes, and is designed for flexible and efficient I/O and for high volume and complex data. Official Site: http://www.hdfgroup.org/HDF5/  ]===])
conflict("hdf5")
prepend_path{"PATH","/export/apps/hdf5/1.8.19/bin",delim=":",priority="0"}
prepend_path{"LD_LIBRARY_PATH","/export/apps/hdf5/1.8.19/lib",delim=":",priority="0"}
