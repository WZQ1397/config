LmodError([===[/home/config/hpc-environment-modules/abyss: (???): couldn't read file "/home/config/hpc-environment-modules/abyss": illegal operation on a directory]===])
