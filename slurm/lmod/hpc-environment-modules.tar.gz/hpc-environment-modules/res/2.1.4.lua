conflict("abyss","openmpi")
prepend_path{"PATH","/export/apps/abyss/2.1.4/bin",delim=":",priority="0"}
prepend_path{"PATH","/usr/lib64/openmpi3/bin",delim=":",priority="0"}
prepend_path{"MANPATH","/export/apps/abyss/2.1.4/bin/share/man",delim=":",priority="0"}
