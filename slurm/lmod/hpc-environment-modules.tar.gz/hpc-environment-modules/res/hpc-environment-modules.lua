LmodError([===[/home/config/hpc-environment-modules: (???): couldn't read file "/home/config/hpc-environment-modules": illegal operation on a directory]===])
