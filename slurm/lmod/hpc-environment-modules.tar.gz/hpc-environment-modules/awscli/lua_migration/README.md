This repository contains artifacts and documentation regarding the migration of modulefiles from Tcl to Lua, performed at UNT HPC.
