LmodError([===[/home/config/hpc-environment-modules/awscli/lua_migration/migration_to_lua.sh: (???): invalid command name "echo"]===])
