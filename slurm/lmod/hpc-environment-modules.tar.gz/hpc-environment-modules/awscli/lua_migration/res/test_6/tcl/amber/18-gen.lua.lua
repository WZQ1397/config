LmodError([===[/home/config/hpc-environment-modules/awscli/lua_migration/test_6/tcl/amber/18-gen.lua: (???): invalid command name "local"]===])
