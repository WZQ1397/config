conflict("awscli","python")
whatis([===[This package provides a unified command line interface to Amazon Web Services.Official site: https://pypi.org/project/awscli  ]===])
prepend_path{"PATH","/opt/apps/awscli/1.17.9/bin",delim=":",priority="0"}
prepend_path{"PYTHONPATH","/opt/apps/awscli/1.17.9/lib/python3.8/site-packages",delim=":",priority="0"}
