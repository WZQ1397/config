LmodError([===[/home/config/hpc-environment-modules/awscli/lua_migration/translate.sh: (???): can't read "LMOD_DIR": no such variable]===])
