echo "[mclz_zach]" > zhosts
for num in `seq 7800 7891`;
do
  echo "box$num ansible_ssh_host=ydian-frp.devmz.cn ansible_ssh_user=nvidia ansible_ssh_port=$num" | tee -a zhosts
done
