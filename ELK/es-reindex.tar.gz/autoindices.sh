month=`date +%Y.%m`
indiceName=$1
esUrl="172.10.101.10:9200"
RED='\E[1;31m'      # 红
GREEN='\E[1;32m'    # 绿
YELOW='\E[1;33m'    # 黄
BLUE='\E[1;34m'     # 蓝
PINK='\E[1;35m'     # 粉红
RES='\E[0m'         # 清除颜色
indiceList=`curl -s http://$esUrl/_cat/indices | grep $indiceName-$month | awk '{print $3}'`
indiceArr=()
index=1
for indice in $indiceList;
do
  indiceArr[$index]=\"$indice\",
  index=$index+1
done

echo -e "${BLUE} =====================| $indiceName-$month-full |====================== ${RES}"
echo " 
curl -X POST 'http://$esUrl/_reindex?wait_for_completion=false' -H 'Content-Type: application/json' -d'
{
\"source\": {
\"index\": [${indiceArr[@]}]
},
\"dest\": {
\"index\": \"$indiceName-$month-full\"
}
}'"
echo -e "${RED} +++++++++++++++++++++|   Run After indice success!   |++++++++++++++++++++ ${RES}"
echo "curl -X POST 'http://$esUrl/$indiceName-$month-full/_close'
"
