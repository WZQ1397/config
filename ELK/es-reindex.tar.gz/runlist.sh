runList=(mobile-ftp tsjr-mobile-prd tsjr-restaurant-prd tsjr-basic-prd)
for indice in ${runList[@]};
do
  bash ./autoindices.sh $indice
done
